package Nguyenhuukyphong._2.BTTHJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtthJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
