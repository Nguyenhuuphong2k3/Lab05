package Nguyenhuukyphong._2.BTTHJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtthJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtthJavaApplication.class, args);
	}

}
