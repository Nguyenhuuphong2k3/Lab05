package Lab5.BTCN;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtcnApplicationTests {

	@Test
	void contextLoads() {
	}

}
